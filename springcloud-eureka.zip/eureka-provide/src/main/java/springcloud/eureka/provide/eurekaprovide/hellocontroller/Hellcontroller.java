package springcloud.eureka.provide.eurekaprovide.hellocontroller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.cloud.client.serviceregistry.Registration;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Description:
 * @Author: Yongkang Hou
 * @Date: 2019-07-25
 */
@RestController
public class Hellcontroller {
    @Autowired
    private Registration getServiceId;// 服务注册
    @Autowired
    private DiscoveryClient client;

    @GetMapping(value = "/hello")
    public String index() {
        List <ServiceInstance> instances = client.getInstances (getServiceId.getServiceId ());
        if (instances != null && instances.size () > 0) {
            System.out.println ("/hello,host:" + instances.get (0).getHost () + ", service_id:" + instances.get (0).getServiceId ());
        }
        return "hello,provider";
    }


}
